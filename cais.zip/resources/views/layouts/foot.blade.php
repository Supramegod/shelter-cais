<footer class="content-footer footer bg-footer-theme">
    <div class="container-fluid">
    <div
        class="footer-container d-flex align-items-center justify-content-between py-3 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
        ©
        <script>
            document.write(new Date().getFullYear());
        </script>
        </div>
    </div>
    </div>
</footer>