<aside id="layout-menu" class="layout-menu-horizontal menu-horizontal menu bg-menu-theme flex-grow-0">
    <div class="container-fluid d-flex h-100">
    <ul class="menu-inner">
        <li class="menu-item @if(Request::url() === route('home')||Request::url() === route('dashboard')) active @endif">
            <a href="{{route('home')}}" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-home-outline"></i>
            <div data-i18n="Dashboards">Dashboards</div>
            </a>
        </li>

        <!-- MARCOMM , MAN MARCOMM -->
        @if(in_array(Auth::user()->role_id,[48,49]))
        <li class="menu-item @if(str_contains(Request::url(), route('leads'))) active @endif">
            <a href="{{route('leads')}}" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-account-search-outline"></i>
            <div data-i18n="Leads">Leads</div>
            </a>
        </li>

        <!-- SALES , TELESALES , SPV SALES , MAN SALES -->
        @elseif(in_array(Auth::user()->role_id,[29,30,31,32,33]))
        <li class="menu-item @if(str_contains(Request::url(), route('leads'))) active @endif">
            <a href="{{route('leads')}}" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-account-search-outline"></i>
            <div data-i18n="Leads">Leads</div>
            </a>
        </li>
        <li class="menu-item @if(str_contains(Request::url(), route('customer-activity'))) active @endif">
            <a href="{{route('customer-activity')}}" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-calendar-check-outline"></i>
            <div data-i18n="Customer Activity">Customer Activity</div>
            </a>
        </li>
        <li class="menu-item @if(str_contains(Request::url(), route('quotation'))) active @endif">
            <a href="{{route('quotation')}}" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-invoice-list-outline"></i>
            <div data-i18n="Quotation">Quotation</div>
            </a>
        </li>
        <!-- RO , SPV Operational , Man Operational -->
        @elseif(in_array(Auth::user()->role_id,[4,5,6,8]))
        <li class="menu-item @if(str_contains(Request::url(), route('leads'))) active @endif">
            <a href="{{route('leads')}}" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-account-search-outline"></i>
            <div data-i18n="Leads">Leads</div>
            </a>
        </li>
        <li class="menu-item @if(str_contains(Request::url(), route('customer-activity'))) active @endif">
            <a href="{{route('customer-activity')}}" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-calendar-check-outline"></i>
            <div data-i18n="Customer Activity">Customer Activity</div>
            </a>
        </li>

        <!-- CRM , SPV CRM , Man CRM -->
        @elseif(in_array(Auth::user()->role_id,[54,55,56]))
        <li class="menu-item @if(str_contains(Request::url(), route('leads'))) active @endif">
            <a href="{{route('leads')}}" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-account-search-outline"></i>
            <div data-i18n="Leads">Leads</div>
            </a>
        </li>
        <li class="menu-item @if(str_contains(Request::url(), route('customer-activity'))) active @endif">
            <a href="{{route('customer-activity')}}" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-calendar-check-outline"></i>
            <div data-i18n="Customer Activity">Customer Activity</div>
            </a>
        </li>
        <!-- SUPER USER -->
        @elseif(in_array(Auth::user()->role_id,[97,98,99,100]))
        <li class="menu-item @if(str_contains(Request::url(), route('quotation'))) active @endif">
            <a href="{{route('quotation')}}" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-invoice-list-outline"></i>
            <div data-i18n="Quotation">Quotation</div>
            </a>
        </li>

        <!-- SUPER USER -->
        @elseif(Auth::user()->role_id==2)
        <li class="menu-item @if(str_contains(Request::url(), route('leads'))) active @endif">
            <a href="{{route('leads')}}" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-account-search-outline"></i>
            <div data-i18n="Leads">Leads</div>
            </a>
        </li>
        <li class="menu-item @if(str_contains(Request::url(), route('customer-activity'))) active @endif">
            <a href="{{route('customer-activity')}}" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-calendar-check-outline"></i>
            <div data-i18n="Customer Activity">Customer Activity</div>
            </a>
        </li>
        <!-- MASTER DATA -->
        <li class="menu-item">
            <a href="javascript:void(0)" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons mdi mdi-database-outline"></i>
                <div data-i18n="Master Data">Master Data</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item @if(str_contains(Request::url(), route('platform'))) active @endif">
                    <a href="{{route('platform')}}" class="menu-link">
                        <i class="menu-icon tf-icons mdi mdi-circle-medium"></i>
                        <div data-i18n="Sumber Leads">Sumber Leads</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a href="#" class="menu-link">
                        <i class="menu-icon tf-icons mdi mdi-circle-medium"></i>
                        <div data-i18n="Jenis Perusahaan">Jenis Perusahaan</div>
                    </a>
                </li>
            </ul>
        </li> 
        @endif
































        
        <!-- <li class="menu-item">
            <a href="javascript:void(0)" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-invoice-list-outline"></i>
            <div data-i18n="Quotation">Quotation</div>
            </a>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0)" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-format-list-text"></i>
            <div data-i18n="SPK">SPK</div>
            </a>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0)" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-file-sign"></i>
            <div data-i18n="PKS">PKS</div>
            </a>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0)" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-file-refresh-outline"></i>
            <div data-i18n="Adendum">Adendum</div>
            </a>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0)" class="menu-link menu-toggle">
            <i class="menu-icon tf-icons mdi mdi-page-next-outline"></i>
            <div data-i18n="Form Lanjutan">Form Lanjutan</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item">
                    <a href="#" class="menu-link">
                        <i class="menu-icon tf-icons mdi mdi-circle-medium"></i>
                        <div data-i18n="Quotation Lanjutan">Quotation Lanjutan</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a href="#" class="menu-link">
                        <i class="menu-icon tf-icons mdi mdi-circle-medium"></i>
                        <div data-i18n="SPK Lanjutan">SPK Lanjutan</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a href="#" class="menu-link">
                        <i class="menu-icon tf-icons mdi mdi-circle-medium"></i>
                        <div data-i18n="SPK Lanjutan">PKS Lanjutan</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a href="#" class="menu-link">
                        <i class="menu-icon tf-icons mdi mdi-circle-medium"></i>
                        <div data-i18n="SPK Lanjutan">Adendum Lanjutan</div>
                    </a>
                </li>
            </ul>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0)" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons mdi mdi-file-cabinet"></i>
                <div data-i18n="Kontrak">Kontrak</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item">
                    <a href="#" class="menu-link">
                        <i class="menu-icon tf-icons mdi mdi-circle-medium"></i>
                        <div data-i18n="Monitoring Kontrak">Monitoring Kontrak</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a href="#" class="menu-link">
                        <i class="menu-icon tf-icons mdi mdi-circle-medium"></i>
                        <div data-i18n="Terminate Kontrak">Terminate Kontrak</div>
                    </a>
                </li>
            </ul>
        </li>
        <li class="menu-item">
            <a href="javascript:void(0)" class="menu-link">
            <i class="menu-icon tf-icons mdi mdi-chart-areaspline"></i>
            <div data-i18n="Report">Report</div>
            </a>
        </li> -->
    </ul>
    </div>
</aside>