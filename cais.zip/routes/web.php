<?php

use Illuminate\Support\Facades\Route;
use App\Http\Middleware\VerifyFastApiKey;

use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Fitur\ContactController;

use App\Http\Controllers\Sales\LeadsController;
use App\Http\Controllers\Sales\CustomerActivityController;
use App\Http\Controllers\Sales\QuotationController;

use App\Http\Controllers\Master\PlatformController;
use App\Http\Controllers\Master\AplikasiPendukungController;
use App\Http\Controllers\Master\JenisBarangController;
use App\Http\Controllers\Master\JabatanController;
use App\Http\Controllers\Master\JenisPerusahaanController;
use App\Http\Controllers\Master\ManagementFeeController;
use App\Http\Controllers\Master\SalaryRuleController;
use App\Http\Controllers\Master\StatusLeadsController;
use App\Http\Controllers\Master\TunjanganController;
use App\Http\Controllers\Master\TunjanganJabatanController;
use App\Http\Controllers\Master\BarangController;


Route::controller(AuthController::class)->group(function() {
    Route::get('/dashboard', 'dashboard')->name('dashboard');
    Route::get('/', 'dashboard')->name('home');
    Route::get('/login', 'login')->name('login');
    Route::post('/logout', 'logout')->name('logout');
    Route::post('/authenticate', 'authenticate')->name('authenticate');
});

//form luar
Route::controller(ContactController::class)->group(function() {
    Route::get('/contact', 'contact')->name('contact');
    Route::post('/contact-save', 'contactSave')->name('contact.save');
    Route::post('/webhook-endpoint/{key}', 'handleWebhook')->name('webhook-endpoint');
});

Route::group(['middleware' => ['verify_leads_api']], function () {
    Route::controller(ContactController::class)->group(function() {
        Route::post('/api/contact-save', 'apiContactSave')->name('api.contact.save');
    });
});

Route::group(['middleware' => ['auth']], function () {
    Route::controller(LeadsController::class)->group(function() {
        Route::get('/sales/leads', 'index')->name('leads');
        Route::get('/sales/leads/add', 'add')->name('leads.add');
        Route::get('/sales/leads/view/{id}', 'view')->name('leads.view');
        Route::get('/sales/leads/import', 'import')->name('leads.import');
        Route::get('/sales/leads/template-import', 'templateImport')->name('leads.template-import');

        Route::post('/sales/leads/inquiry-import', 'inquiryImport')->name('leads.inquiry-import');
        Route::post('/sales/leads/save-import', 'saveImport')->name('leads.save-import');
        Route::post('/sales/leads/save', 'save')->name('leads.save');
        Route::post('/sales/leads/delete', 'delete')->name('leads.delete');

        Route::get('/sales/leads/export-excel', 'exportExcel')->name('leads.export-excel');

        Route::get('/sales/leads/list', 'list')->name('leads.list'); // ajax
        Route::get('/sales/leads/leads.available-leads', 'availableLeads')->name('leads.available-leads'); // ajax

    });

    Route::controller(CustomerActivityController::class)->group(function() {
        Route::get('/sales/customer-activity', 'index')->name('customer-activity');
        Route::get('/sales/customer-activity/add', 'add')->name('customer-activity.add');
        Route::get('/sales/customer-activity/view/{id}', 'view')->name('customer-activity.view');

        Route::post('/sales/customer-activity/save', 'save')->name('customer-activity.save');
        Route::post('/sales/customer-activity/delete', 'delete')->name('customer-activity.delete');

        Route::get('/sales/customer-activity/list', 'list')->name('customer-activity.list'); // ajax
        Route::get('/sales/customer-activity/member-tim-sales', 'memberTimSales')->name('customer-activity.member-tim-sales'); // ajax
    });

    Route::controller(QuotationController::class)->group(function() {
        Route::get('/sales/quotation', 'index')->name('quotation');
        Route::get('/sales/quotation/add', 'add')->name('quotation.add');
        Route::get('/sales/quotation/step/{id}', 'step')->name('quotation.step');
        Route::post('/sales/quotation/save-step', 'saveStep')->name('quotation.save-step');

        //page quotation
        Route::get('/sales/quotation/view/{id}', 'view')->name('quotation.view');

        Route::post('/sales/quotation/save', 'save')->name('quotation.save');
        Route::post('/sales/quotation/saveEdit1', 'saveEdit1')->name('quotation.save-edit-1');
        Route::post('/sales/quotation/saveEdit2', 'saveEdit2')->name('quotation.save-edit-2');
        Route::post('/sales/quotation/saveEdit3', 'saveEdit3')->name('quotation.save-edit-3');
        Route::post('/sales/quotation/saveEdit4', 'saveEdit4')->name('quotation.save-edit-4');
        Route::post('/sales/quotation/saveEdit5', 'saveEdit5')->name('quotation.save-edit-5');
        Route::post('/sales/quotation/saveEdit6', 'saveEdit6')->name('quotation.save-edit-6');
        Route::post('/sales/quotation/saveEdit7', 'saveEdit7')->name('quotation.save-edit-7');
        Route::post('/sales/quotation/saveEdit8', 'saveEdit8')->name('quotation.save-edit-8');
        Route::post('/sales/quotation/saveEdit9', 'saveEdit9')->name('quotation.save-edit-9');
        Route::post('/sales/quotation/saveEdit10', 'saveEdit10')->name('quotation.save-edit-10');
        Route::post('/sales/quotation/saveEdit11', 'saveEdit11')->name('quotation.save-edit-11');
        Route::post('/sales/quotation/saveEdit12', 'saveEdit12')->name('quotation.save-edit-12');
        Route::post('/sales/quotation/saveEdit13', 'saveEdit13')->name('quotation.save-edit-13');

        Route::post('/sales/quotation/delete', 'delete')->name('quotation.delete');

        Route::get('/sales/quotation/list', 'list')->name('quotation.list'); // ajax
        Route::post('/sales/quotation/add-detail-hc', 'addDetailHC')->name('quotation.add-detail-hc');
        Route::get('/sales/quotation/list-detail-hc', 'listDetailHC')->name('quotation.list-detail-hc'); // ajax
        Route::post('/sales/quotation/delete-detail-hc', 'deleteDetailHC')->name('quotation.delete-detail-hc');
        Route::get('/sales/quotation/change-kota', 'changeKota')->name('quotation.change-kota'); // ajax
        Route::get('/sales/quotation/list-quotation-kerjasama', 'listQuotationKerjasama')->name('quotation.list-quotation-kerjasama'); // ajax
        Route::post('/sales/quotation/add-quotation-kerjasama', 'addQuotationKerjasama')->name('quotation.add-quotation-kerjasama');
        Route::post('/sales/quotation/delete-quotation-kerjasama', 'deleteQuotationKerjasama')->name('quotation.delete-quotation-kerjasama');
        Route::post('/sales/quotation/delete-quotation', 'deleteQuotation')->name('quotation.delete-quotation');
        Route::post('/sales/quotation/approve-quotation', 'approveQuotation')->name('quotation.approve-quotation');

        //KAPORLAP
        Route::get('/sales/quotation/list-kaporlap', 'listKaporlap')->name('quotation.list-kaporlap'); // ajax
        Route::post('/sales/quotation/add-detail-kaporlap', 'addDetailKaporlap')->name('quotation.add-detail-kaporlap');
        Route::post('/sales/quotation/delete-detail-kaporlap', 'deleteDetailKaporlap')->name('quotation.delete-detail-kaporlap');

        //OHC
        Route::get('/sales/quotation/list-ohc', 'listOhc')->name('quotation.list-ohc'); // ajax
        Route::post('/sales/quotation/add-detail-ohc', 'addDetailOhc')->name('quotation.add-detail-ohc');
        Route::post('/sales/quotation/delete-detail-ohc', 'deleteDetailOhc')->name('quotation.delete-detail-ohc');

        //DEVICES
        Route::get('/sales/quotation/list-devices', 'listDevices')->name('quotation.list-devices'); // ajax
        Route::post('/sales/quotation/add-detail-devices', 'addDetailDevices')->name('quotation.add-detail-devices');
        Route::post('/sales/quotation/delete-detail-devices', 'deleteDetailDevices')->name('quotation.delete-detail-devices');

        //CHEMICAL
        Route::get('/sales/quotation/list-chemical', 'listChemical')->name('quotation.list-chemical'); // ajax
        Route::post('/sales/quotation/add-detail-chemical', 'addDetailChemical')->name('quotation.add-detail-chemical');
        Route::post('/sales/quotation/delete-detail-chemical', 'deleteDetailChemical')->name('quotation.delete-detail-chemical');

        Route::post('/sales/quotation/add-biaya-monitoring', 'addBiayaMonitoring')->name('quotation.add-biaya-monitoring');

        Route::get('/sales/quotation/cetak-checklist/{id}', 'cetakChecklist')->name('quotation.cetak-checklist');

    });


    Route::controller(PlatformController::class)->group(function() {
        Route::get('/master/platform', 'index')->name('platform');
        Route::get('/master/platform/add', 'add')->name('platform.add');
        Route::get('/master/platform/view/{id}', 'view')->name('platform.view');

        Route::post('/master/platform/save', 'save')->name('platform.save');
        Route::post('/master/platform/delete', 'delete')->name('platform.delete');

        Route::get('/master/platform/list', 'list')->name('platform.list'); // ajax

    });

    Route::controller(AplikasiPendukungController::class)->group(function() {
        Route::get('/master/aplikasi-pendukung', 'index')->name('aplikasi-pendukung');
        Route::get('/master/aplikasi-pendukung/add', 'add')->name('aplikasi-pendukung.add');
        Route::get('/master/aplikasi-pendukung/view/{id}', 'view')->name('aplikasi-pendukung.view');

        Route::post('/master/aplikasi-pendukung/save', 'save')->name('aplikasi-pendukung.save');
        Route::post('/master/aplikasi-pendukung/delete', 'delete')->name('aplikasi-pendukung.delete');

        Route::get('/master/aplikasi-pendukung/list', 'list')->name('aplikasi-pendukung.list'); // ajax

    });
    
    Route::controller(JenisBarangController::class)->group(function() {
        Route::get('/master/jenis-barang', 'index')->name('jenis-barang');
        Route::get('/master/jenis-barang/view/{id}', 'view')->name('jenis-barang.view');

        Route::get('/master/jenis-barang/list', 'list')->name('jenis-barang.list'); // ajax
        Route::get('/master/jenis-barang/detail-barang', 'detailBarang')->name('jenis-barang.detail-barang'); // ajax

    });

    Route::controller(JabatanController::class)->group(function() {
        Route::get('/master/jabatan', 'index')->name('jabatan');
        Route::get('/master/jabatan/add', 'add')->name('jabatan.add');
        Route::get('/master/jabatan/view/{id}', 'view')->name('jabatan.view');

        Route::post('/master/jabatan/save', 'save')->name('jabatan.save');
        Route::post('/master/jabatan/delete', 'delete')->name('jabatan.delete');

        Route::get('/master/jabatan/list', 'list')->name('jabatan.list'); // ajax

    });

    Route::controller(JenisPerusahaanController::class)->group(function() {
        Route::get('/master/perusahaan', 'index')->name('perusahaan');
        Route::get('/master/perusahaan/add', 'add')->name('perusahaan.add');
        Route::get('/master/perusahaan/view/{id}', 'view')->name('perusahaan.view');

        Route::post('/master/perusahaan/save', 'save')->name('perusahaan.save');
        Route::post('/master/perusahaan/delete', 'delete')->name('perusahaan.delete');

        Route::get('/master/perusahaan/list', 'list')->name('perusahaan.list'); // ajax

    });
    
    Route::controller(ManagementFeeController::class)->group(function() {
        Route::get('/master/management-fee', 'index')->name('management-fee');
        Route::get('/master/management-fee/add', 'add')->name('management-fee.add');
        Route::get('/master/management-fee/view/{id}', 'view')->name('management-fee.view');

        Route::post('/master/management-fee/save', 'save')->name('management-fee.save');
        Route::post('/master/management-fee/delete', 'delete')->name('management-fee.delete');

        Route::get('/master/management-fee/list', 'list')->name('management-fee.list'); // ajax

    });
    
    Route::controller(SalaryRuleController::class)->group(function() {
        Route::get('/master/salary-rule', 'index')->name('salary-rule');
        Route::get('/master/salary-rule/add', 'add')->name('salary-rule.add');
        Route::get('/master/salary-rule/view/{id}', 'view')->name('salary-rule.view');

        Route::post('/master/salary-rule/save', 'save')->name('salary-rule.save');
        Route::post('/master/salary-rule/delete', 'delete')->name('salary-rule.delete');

        Route::get('/master/salary-rule/list', 'list')->name('salary-rule.list'); // ajax

    });
    
    Route::controller(StatusLeadsController::class)->group(function() {
        Route::get('/master/status-leads', 'index')->name('status-leads');

        Route::get('/master/status-leads/list', 'list')->name('status-leads.list'); // ajax

    });
    
    Route::controller(TunjanganController::class)->group(function() {
        Route::get('/master/tunjangan', 'index')->name('tunjangan');
        Route::get('/master/tunjangan/add', 'add')->name('tunjangan.add');
        Route::get('/master/tunjangan/view/{id}', 'view')->name('tunjangan.view');

        Route::post('/master/tunjangan/save', 'save')->name('tunjangan.save');
        Route::post('/master/tunjangan/delete', 'delete')->name('tunjangan.delete');

        Route::get('/master/tunjangan/list', 'list')->name('tunjangan.list'); // ajax

    });
    
    Route::controller(TunjanganJabatanController::class)->group(function() {
        Route::get('/master/tunjangan-jabatan', 'index')->name('tunjangan-jabatan');
        Route::get('/master/tunjangan-jabatan/add', 'add')->name('tunjangan-jabatan.add');
        Route::get('/master/tunjangan-jabatan/view/{id}', 'view')->name('tunjangan-jabatan.view');

        Route::post('/master/tunjangan-jabatan/save', 'save')->name('tunjangan-jabatan.save');
        Route::post('/master/tunjangan-jabatan/delete', 'delete')->name('tunjangan-jabatan.delete');

        Route::get('/master/tunjangan-jabatan/list', 'list')->name('tunjangan-jabatan.list'); // ajax
        Route::get('/master/tunjangan-jabatan/get-kebutuhan-detail', 'getKebutuhanDetail')->name('tunjangan-jabatan.get-kebutuhan-detail'); // ajax

    });
    
    Route::controller(BarangController::class)->group(function() {
        Route::get('/master/barang', 'index')->name('barang');
        Route::get('/master/barang/add', 'add')->name('barang.add');
        Route::get('/master/barang/view/{id}', 'view')->name('barang.view');

        Route::post('/master/barang/save', 'save')->name('barang.save');
        Route::post('/master/barang/delete', 'delete')->name('barang.delete');

        Route::get('/master/barang/list', 'list')->name('barang.list'); // ajax
    });
});